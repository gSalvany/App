# Apps pessoais — Atrium, Memento, Volumen e Cognitio

Publicados juntos no GitHub Pages, os quatro ficam no mesmo endereço,
podem ser instalados no celular e funcionam sem internet.
Os dados de cada app ficam só no navegador do aparelho; este repositório guarda apenas o código.

## Arquivos
- `index.html` — Atrium (página inicial, lê os outros três direto)
- `memento.html`, `volumen.html`, `cognitio.html` — os apps
- `*.webmanifest` e `icon-*.png` — nome e ícone de cada app instalado
- `sw.js` — guarda os arquivos para abrir offline

## Ao atualizar um app
1. Envie o arquivo novo com o **mesmo nome**.
2. Em `sw.js`, aumente `VERSION` (ex.: `apps-v1` → `apps-v2`) para o celular renovar a cópia offline.
3. Nunca publique neste endereço páginas de terceiros: tudo em `seunome.github.io` compartilha o armazenamento.
