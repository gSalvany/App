/* Service worker compartilhado pelos quatro apps.
   Guarda os arquivos no aparelho para abrir sem internet.
   Páginas: tenta a rede primeiro (para receber atualizações) e usa a cópia guardada se estiver offline.
   Ícones e manifests: usa a cópia guardada.
   Os DADOS dos apps não passam por aqui: continuam no localStorage/IndexedDB do navegador.
   Ao publicar uma versão nova de qualquer app, aumente VERSION para renovar a cópia offline. */
const VERSION = 'apps-v1';
const FILES = ["./", "index.html", "memento.html", "volumen.html", "cognitio.html", "atrium.webmanifest", "memento.webmanifest", "volumen.webmanifest", "cognitio.webmanifest", "icon-atrium-192.png", "icon-atrium-512.png", "icon-atrium-maskable-512.png", "icon-atrium-180.png", "icon-memento-192.png", "icon-memento-512.png", "icon-memento-maskable-512.png", "icon-memento-180.png", "icon-volumen-192.png", "icon-volumen-512.png", "icon-volumen-maskable-512.png", "icon-volumen-180.png", "icon-cognitio-192.png", "icon-cognitio-512.png", "icon-cognitio-maskable-512.png", "icon-cognitio-180.png"];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(VERSION).then(c => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  const req = e.request, url = new URL(req.url);
  if (req.method !== 'GET' || url.origin !== location.origin) return;
  const isPage = req.mode === 'navigate' || url.pathname.endsWith('.html') || url.pathname.endsWith('/');
  if (isPage) {
    e.respondWith(fetch(req).then(res => {
      if (res.ok) { const copy = res.clone(); caches.open(VERSION).then(c => c.put(req, copy)); }
      return res;
    }).catch(() => caches.match(req, { ignoreSearch: true }).then(r => r || caches.match('index.html'))));
    return;
  }
  e.respondWith(caches.match(req).then(r => r || fetch(req).then(res => {
    if (res.ok) { const copy = res.clone(); caches.open(VERSION).then(c => c.put(req, copy)); }
    return res;
  })));
});
